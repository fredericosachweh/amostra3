jQuery(function($){
	
	/**
	 * Load
	 *
	 */
	$('#load div').animate({ opacity : 1, top : '50%' }, 500)
		.find(':last').animate({ opacity : 1, 'margin-top' : 0 }, 600);
	
	
	
	/* =========================
	for( var i = 0; i < 15; i++ ) {
		$( '#drop' ).append( '<figure></figure>' );
	}
	// =========================*/
	
	
	
	
	// Elementos Draggable
	var drag1, drag2, drag3, drag4, drag5, drag6, drag7, drag8, drag9, drag10, drag11, drag12, drag13, drag14, drag15;
	var cont1 = 0, cont2 = 0, cont3 = 0, cont4 = 0, cont5 = 0, cont6 = 0, cont7 = 0, cont8 = 0, cont9 = 0, cont10 = 0,
		cont11 = 0, cont12 = 0, cont13 = 0, cont14 = 0, cont15 = 0;
	
	drag1 = new webkit_draggable('drag1', {
		onStart : function() {
			$('.container-drag1').append( $('#drag1').clone().addClass('cloned').attr('id', 'drag1_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag1')[0] ) {
				$('.container-drag1').find('#drag1_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	
	drag2 = new webkit_draggable('drag2', {
		onStart : function() {
			$('.container-drag2').append( $('#drag2').clone().addClass('cloned').attr('id', 'drag2_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag2')[0] ) {
				$('.container-drag2').find('#drag2_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	
	drag3 = new webkit_draggable('drag3', {
		onStart : function() {
			$('.container-drag3').append( $('#drag3').clone().addClass('cloned').attr('id', 'drag3_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag3')[0] ) {
				$('.container-drag3').find('#drag3_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	drag4 = new webkit_draggable('drag4', {
		onStart : function() {
			$('.container-drag4').append( $('#drag4').clone().addClass('cloned').attr('id', 'drag4_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag4')[0] ) {
				$('.container-drag4').find('#drag4_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	drag5 = new webkit_draggable('drag5', {
		onStart : function() {
			$('.container-drag5').append( $('#drag5').clone().addClass('cloned').attr('id', 'drag5_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag5')[0] ) {
				$('.container-drag5').find('#drag5_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	drag6 = new webkit_draggable('drag6', {
		onStart : function() {
			$('.container-drag6').append( $('#drag6').clone().addClass('cloned').attr('id', 'drag6_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag6')[0] ) {
				$('.container-drag6').find('#drag6_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	drag7 = new webkit_draggable('drag7', {
		onStart : function() {
			$('.container-drag7').append( $('#drag7').clone().addClass('cloned').attr('id', 'drag7_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag7')[0] ) {
				$('.container-drag7').find('#drag7_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	drag8 = new webkit_draggable('drag8', {
		onStart : function() {
			$('.container-drag8').append( $('#drag8').clone().addClass('cloned').attr('id', 'drag8_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag8')[0] ) {
				$('.container-drag8').find('#drag8_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	drag9 = new webkit_draggable('drag9', {
		onStart : function() {
			$('.container-drag9').append( $('#drag9').clone().addClass('cloned').attr('id', 'drag9_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag9')[0] ) {
				$('.container-drag9').find('#drag9_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	drag10 = new webkit_draggable('drag10', {
		onStart : function() {
			$('.container-drag10').append( $('#drag10').clone().addClass('cloned').attr('id', 'drag10_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag10')[0] ) {
				$('.container-drag10').find('#drag10_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	drag11 = new webkit_draggable('drag11', {
		onStart : function() {
			$('.container-drag11').append( $('#drag11').clone().addClass('cloned').attr('id', 'drag11_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag11')[0] ) {
				$('.container-drag11').find('#drag11_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	drag12 = new webkit_draggable('drag12', {
		onStart : function() {
			$('.container-drag12').append( $('#drag12').clone().addClass('cloned').attr('id', 'drag12_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag12')[0] ) {
				$('.container-drag12').find('#drag12_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	drag13 = new webkit_draggable('drag13', {
		onStart : function() {
			$('.container-drag13').append( $('#drag13').clone().addClass('cloned').attr('id', 'drag13_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag13')[0] ) {
				$('.container-drag13').find('#drag13_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	drag14 = new webkit_draggable('drag14', {
		onStart : function() {
			$('.container-drag14').append( $('#drag14').clone().addClass('cloned').attr('id', 'drag14_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag14')[0] ) {
				$('.container-drag14').find('#drag14_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	drag15 = new webkit_draggable('drag15', {
		onStart : function() {
			$('.container-drag15').append( $('#drag15').clone().addClass('cloned').attr('id', 'drag15_cloned').css('bottom', 0) );
		},
		
		onEnd : function() {
			if( ! $('#drop').find('#drag15')[0] ) {
				$('.container-drag15').find('#drag15_cloned').remove();
			}
		},
		
		revert : true
	});
	
	
	
	
	
	
	
	
	
	
	// Área de drop
	webkit_drop.add('drop', {
		onDrop : function(elem, e) {
			
			// Dropar a imagem 1 (drag1)
			if( $(elem).attr('id') == 'drag1' || $(elem).attr('id') == 'drag1_cloned' ) {
				if( ! $(elem + '[id$=1_cloned]')[0] ){
					$('.container-drag1').append( $('#drag1').clone().addClass('cloned').attr('id', 'drag1_cloned').css('bottom', 0) );
				}
				
				cont1++;
				//=========================================================
				if( ! $( '#fig1' )[0] ) {
					$( '#drop' ).append( '<figure id="fig1"></figure>' );
				}
				
				$( '#fig1' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont1 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont1 );
					}
				});
				//=========================================================
				
				$('.container-drag1').find('[id$=_cloned]').attr('id', 'drag1');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag1 = new webkit_draggable('drag1', {
					onStart : function() {
						$('.container-drag1').append( $('#drag1').clone().addClass('cloned').attr('id', 'drag1_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag1')[0] ) {
							$('.container-drag1').find('#drag1_cloned').remove();
						}
					},
					
					revert : true
				});
				
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.1').text( cont1 );
			}
			
			
			//Dropar a imagem 2 (drag2)
			if( $(elem).attr('id') == 'drag2' || $(elem).attr('id') == 'drag2_cloned' ){
				if( ! $(elem + '[id$=2_cloned]')[0] ){
					$('.container-drag2').append( $('#drag2').clone().addClass('cloned').attr('id', 'drag1_cloned').css('bottom', 0) );
				}
				
				cont2++;
				//=========================================================
				if( ! $( '#fig2' )[0] ) {
					$( '#drop' ).append( '<figure id="fig2"></figure>' );
				}
				
				$( '#fig2' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont2 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont2 );
					}
				});
				//=========================================================
				$('.container-drag2').find('[id$=_cloned]').attr('id', 'drag2');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag2 = new webkit_draggable('drag2', {
					onStart : function() {
						$('.container-drag2').append( $('#drag2').clone().addClass('cloned').attr('id', 'drag2_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag2')[0] ) {
							$('.container-drag2').find('#drag2_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.2').text( cont2 );
			}
			
			
			//Dropar a imagem 3 (drag3)
			if( $(elem).attr('id') == 'drag3' || $(elem).attr('id') == 'drag3_cloned' ){
				if( ! $(elem + '[id$=3_cloned]')[0] ){
					$('.container-drag3').append( $('#drag3').clone().addClass('cloned').attr('id', 'drag3_cloned').css('bottom', 0) );
				}
				
				cont3++;
				//=========================================================
				if( ! $( '#fig3' )[0] ) {
					$( '#drop' ).append( '<figure id="fig3"></figure>' );
				}
				
				$( '#fig3' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont3 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont3 );
					}
				});
				//=========================================================
				$('.container-drag3').find('[id$=_cloned]').attr('id', 'drag3');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag3 = new webkit_draggable('drag3', {
					onStart : function() {
						$('.container-drag3').append( $('#drag3').clone().addClass('cloned').attr('id', 'drag3_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag3')[0] ) {
							$('.container-drag3').find('#drag3_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.3').text( cont3 );
			}
			
			
			//Dropar a imagem 4 (drag4)
			if( $(elem).attr('id') == 'drag4' || $(elem).attr('id') == 'drag4_cloned' ){
				if( ! $(elem + '[id$=4_cloned]')[0] ){
					$('.container-drag4').append( $('#drag4').clone().addClass('cloned').attr('id', 'drag4_cloned').css('bottom', 0) );
				}
				
				cont4++;
				//=========================================================
				if( ! $( '#fig4' )[0] ) {
					$( '#drop' ).append( '<figure id="fig4"></figure>' );
				}
				
				$( '#fig4' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont4 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont4 );
					}
				});
				//=========================================================
				$('.container-drag4').find('[id$=_cloned]').attr('id', 'drag4');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag4 = new webkit_draggable('drag4', {
					onStart : function() {
						$('.container-drag4').append( $('#drag4').clone().addClass('cloned').attr('id', 'drag4_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag4')[0] ) {
							$('.container-drag4').find('#drag4_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.4').text( cont4 );
			}
			
			
			//Dropar a imagem 5 (drag5)
			if( $(elem).attr('id') == 'drag5' || $(elem).attr('id') == 'drag5_cloned' ){
				if( ! $(elem + '[id$=5_cloned]')[0] ){
					$('.container-drag5').append( $('#drag5').clone().addClass('cloned').attr('id', 'drag5_cloned').css('bottom', 0) );
				}
				
				cont5++;
				//=========================================================
				if( ! $( '#fig5' )[0] ) {
					$( '#drop' ).append( '<figure id="fig5"></figure>' );
				}
				
				$( '#fig5' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont5 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont5 );
					}
				});
				//=========================================================
				$('.container-drag5').find('[id$=_cloned]').attr('id', 'drag5');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag5 = new webkit_draggable('drag5', {
					onStart : function() {
						$('.container-drag5').append( $('#drag5').clone().addClass('cloned').attr('id', 'drag5_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag5')[0] ) {
							$('.container-drag5').find('#drag5_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.5').text( cont5 );
			}
			
			
			//Dropar a imagem 6 (drag6)
			if( $(elem).attr('id') == 'drag6' || $(elem).attr('id') == 'drag6_cloned' ){
				if( ! $(elem + '[id$=6_cloned]')[0] ){
					$('.container-drag6').append( $('#drag6').clone().addClass('cloned').attr('id', 'drag6_cloned').css('bottom', 0) );
				}
				
				cont6++;
				//=========================================================
				if( ! $( '#fig6' )[0] ) {
					$( '#drop' ).append( '<figure id="fig6"></figure>' );
				}
				
				$( '#fig6' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont6 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont6 );
					}
				});
				//=========================================================
				$('.container-drag6').find('[id$=_cloned]').attr('id', 'drag6');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag6 = new webkit_draggable('drag6', {
					onStart : function() {
						$('.container-drag6').append( $('#drag6').clone().addClass('cloned').attr('id', 'drag6_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag6')[0] ) {
							$('.container-drag6').find('#drag6_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.6').text( cont6 );
			}
			
			
			//Dropar a imagem 7 (drag7)
			if( $(elem).attr('id') == 'drag7' || $(elem).attr('id') == 'drag7_cloned' ){
				if( ! $(elem + '[id$=7_cloned]')[0] ){
					$('.container-drag7').append( $('#drag7').clone().addClass('cloned').attr('id', 'drag7_cloned').css('bottom', 0) );
				}
				
				cont7++;
				//=========================================================
				if( ! $( '#fig7' )[0] ) {
					$( '#drop' ).append( '<figure id="fig7"></figure>' );
				}
				
				$( '#fig7' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont7 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont7 );
					}
				});
				//=========================================================
				$('.container-drag7').find('[id$=_cloned]').attr('id', 'drag7');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag7 = new webkit_draggable('drag7', {
					onStart : function() {
						$('.container-drag7').append( $('#drag7').clone().addClass('cloned').attr('id', 'drag7_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag7')[0] ) {
							$('.container-drag7').find('#drag7_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.7').text( cont7 );
			}
			
			
			//Dropar a imagem 8 (drag8)
			if( $(elem).attr('id') == 'drag8' || $(elem).attr('id') == 'drag8_cloned' ){
				if( ! $(elem + '[id$=8_cloned]')[0] ){
					$('.container-drag8').append( $('#drag8').clone().addClass('cloned').attr('id', 'drag8_cloned').css('bottom', 0) );
				}
				
				cont8++;
				//=========================================================
				if( ! $( '#fig8' )[0] ) {
					$( '#drop' ).append( '<figure id="fig8"></figure>' );
				}
				
				$( '#fig8' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont8 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont8 );
					}
				});
				//=========================================================
				$('.container-drag8').find('[id$=_cloned]').attr('id', 'drag8');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag8 = new webkit_draggable('drag8', {
					onStart : function() {
						$('.container-drag8').append( $('#drag8').clone().addClass('cloned').attr('id', 'drag8_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag8')[0] ) {
							$('.container-drag8').find('#drag8_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.8').text( cont8 );
			}
			
			
			//Dropar a imagem 9 (drag9)
			if( $(elem).attr('id') == 'drag9' || $(elem).attr('id') == 'drag9_cloned' ){
				if( ! $(elem + '[id$=9_cloned]')[0] ){
					$('.container-drag9').append( $('#drag9').clone().addClass('cloned').attr('id', 'drag9_cloned').css('bottom', 0) );
				}
				
				cont9++;
				//=========================================================
				if( ! $( '#fig9' )[0] ) {
					$( '#drop' ).append( '<figure id="fig9"></figure>' );
				}
				
				$( '#fig9' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont9 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont9 );
					}
				});
				//=========================================================
				$('.container-drag9').find('[id$=_cloned]').attr('id', 'drag9');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag9 = new webkit_draggable('drag9', {
					onStart : function() {
						$('.container-drag9').append( $('#drag9').clone().addClass('cloned').attr('id', 'drag9_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag9')[0] ) {
							$('.container-drag9').find('#drag9_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.9').text( cont9 );
			}
			
			
			//Dropar a imagem 10 (drag10)
			if( $(elem).attr('id') == 'drag10' || $(elem).attr('id') == 'drag10_cloned' ){
				if( ! $(elem + '[id$=10_cloned]')[0] ){
					$('.container-drag10').append( $('#drag10').clone().addClass('cloned').attr('id', 'drag10_cloned').css('bottom', 0) );
				}
				
				cont10++;
				//=========================================================
				if( ! $( '#fig10' )[0] ) {
					$( '#drop' ).append( '<figure id="fig10"></figure>' );
				}
				
				$( '#fig10' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont10 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont10 );
					}
				});
				//=========================================================
				$('.container-drag10').find('[id$=_cloned]').attr('id', 'drag10');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag10 = new webkit_draggable('drag10', {
					onStart : function() {
						$('.container-drag10').append( $('#drag10').clone().addClass('cloned').attr('id', 'drag10_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag10')[0] ) {
							$('.container-drag10').find('#drag10_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.10').text( cont10 );
			}
			
			
			//Dropar a imagem 11 (drag11)
			if( $(elem).attr('id') == 'drag11' || $(elem).attr('id') == 'drag11_cloned' ){
				if( ! $(elem + '[id$=11_cloned]')[0] ){
					$('.container-drag11').append( $('#drag11').clone().addClass('cloned').attr('id', 'drag11_cloned').css('bottom', 0) );
				}
				
				cont11++;
				//=========================================================
				if( ! $( '#fig11' )[0] ) {
					$( '#drop' ).append( '<figure id="fig11"></figure>' );
				}
				
				$( '#fig11' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont11 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont11 );
					}
				});
				//=========================================================
				$('.container-drag11').find('[id$=_cloned]').attr('id', 'drag11');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag11 = new webkit_draggable('drag11', {
					onStart : function() {
						$('.container-drag11').append( $('#drag11').clone().addClass('cloned').attr('id', 'drag11_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag11')[0] ) {
							$('.container-drag11').find('#drag11_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.11').text( cont11 );
			}
			
			//Dropar a imagem 12 (drag12)
			if( $(elem).attr('id') == 'drag12' || $(elem).attr('id') == 'drag12_cloned' ){
				if( ! $(elem + '[id$=12_cloned]')[0] ){
					$('.container-drag12').append( $('#drag12').clone().addClass('cloned').attr('id', 'drag12_cloned').css('bottom', 0) );
				}
				
				cont12++;
				//=========================================================
				if( ! $( '#fig12' )[0] ) {
					$( '#drop' ).append( '<figure id="fig12"></figure>' );
				}
				
				$( '#fig12' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont12 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont12 );
					}
				});
				//=========================================================
				$('.container-drag12').find('[id$=_cloned]').attr('id', 'drag12');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag12 = new webkit_draggable('drag12', {
					onStart : function() {
						$('.container-drag12').append( $('#drag12').clone().addClass('cloned').attr('id', 'drag12_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag12')[0] ) {
							$('.container-drag12').find('#drag12_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.12').text( cont12 );
			}
			
			//Dropar a imagem 13 (drag13)
			if( $(elem).attr('id') == 'drag13' || $(elem).attr('id') == 'drag13_cloned' ){
				if( ! $(elem + '[id$=13_cloned]')[0] ){
					$('.container-drag13').append( $('#drag13').clone().addClass('cloned').attr('id', 'drag13_cloned').css('bottom', 0) );
				}
				
				cont13++;
				//=========================================================
				if( ! $( '#fig13' )[0] ) {
					$( '#drop' ).append( '<figure id="fig13"></figure>' );
				}
				
				$( '#fig13' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont13 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont13 );
					}
				});
				//=========================================================
				$('.container-drag13').find('[id$=_cloned]').attr('id', 'drag13');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag13 = new webkit_draggable('drag13', {
					onStart : function() {
						$('.container-drag13').append( $('#drag13').clone().addClass('cloned').attr('id', 'drag13_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag13')[0] ) {
							$('.container-drag13').find('#drag13_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.13').text( cont13 );
			}
			
			//Dropar a imagem 14 (drag14)
			if( $(elem).attr('id') == 'drag14' || $(elem).attr('id') == 'drag14_cloned' ){
				if( ! $(elem + '[id$=14_cloned]')[0] ){
					$('.container-drag14').append( $('#drag14').clone().addClass('cloned').attr('id', 'drag14_cloned').css('bottom', 0) );
				}
				
				cont14++;
				//=========================================================
				if( ! $( '#fig14' )[0] ) {
					$( '#drop' ).append( '<figure id="fig14"></figure>' );
				}
				
				$( '#fig14' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont14 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont14 );
					}
				});
				//=========================================================
				$('.container-drag14').find('[id$=_cloned]').attr('id', 'drag14');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag14 = new webkit_draggable('drag14', {
					onStart : function() {
						$('.container-drag14').append( $('#drag14').clone().addClass('cloned').attr('id', 'drag14_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag14')[0] ) {
							$('.container-drag14').find('#drag14_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.14').text( cont14 );
			}
			
			//Dropar a imagem 15 (drag15)
			if( $(elem).attr('id') == 'drag15' || $(elem).attr('id') == 'drag15_cloned' ){
				if( ! $(elem + '[id$=15_cloned]')[0] ){
					$('.container-drag15').append( $('#drag15').clone().addClass('cloned').attr('id', 'drag15_cloned').css('bottom', 0) );
				}
				
				cont15++;
				//=========================================================
				if( ! $( '#fig15' )[0] ) {
					$( '#drop' ).append( '<figure id="fig15"></figure>' );
				}
				
				$( '#fig15' ).each(function() {
					if( ! $( this ).find( 'img' )[0] ) {
						$( this ).append( $(elem).removeAttr('id') );
					} else {
						$( elem ).remove();
					}
					
					if( ! $( this ).find( 'figcaption' )[0] ) {
						$( this ).append( '<figcaption>' + cont15 + '</figcaption>' );
					} else {
						$( this ).find( 'figcaption' ).text( cont15 );
					}
				});
				//=========================================================
				$('.container-drag15').find('[id$=_cloned]').attr('id', 'drag15');
				
				
				// Aplica o drag no elemento clonado (repete o drag do elemento original)
				drag15 = new webkit_draggable('drag15', {
					onStart : function() {
						$('.container-drag15').append( $('#drag15').clone().addClass('cloned').attr('id', 'drag15_cloned').css('bottom', 0) );
					},
					
					onEnd : function() {
						if( ! $('#drop').find('#drag15')[0] ) {
							$('.container-drag15').find('#drag15_cloned').remove();
						}
					},
					
					revert : true
				});
				
				$( '#bt-limpar, #bt-descubra' ).removeClass( 'bt-disabled' );
				$('.15').text( cont15 );
			}
			
		},
		
		onOver : function() {
			
		},
		
		onOut : function() {
			
		},
		
		hoverClass : 'dropped'
	});
	
	
	
	
	
	
	
	
	
	
	/**
	 * Navegação pelo slide por cliques
	 * e configurações do tamanho e opacidade das imagens
	 * 
	 */
	var contador = 12;
	//$('#carousel').find('ul :first, ul :nth-child(3)').find('img').addClass('disabled');
	$('#next').click(function(){
		if( contador > 0 ) {
			contador--;
			
			$('#carousel').find('ul').each(function(){
				$(this).animate({ left : $(this).position().left - 141 + 'px' }, 150);
			});
		} else {
			$('#carousel').find('ul').each(function(){
				$(this).animate({ left : 0 }, 200);
			});
			contador = 12;
		}
	});
	
	$('#prev').click(function(){
		if( contador < 12 ) {
			contador++;
			
			$('#carousel').find('ul').each(function(){
				$(this).animate({ left : $(this).position().left + 141 + 'px' }, 150);
			});
		} else {
			$('#carousel').find('ul').each(function(){
				$(this).animate({ left : '-1692px' }, 200);
			});
			contador = 0;
		}
	});
	
	
	
	
	
	
	
	
	
	
	/**
	 * Ação dos botões Descubra, Limpar e Refazer
	 * 
	 */
	$( '.bt-disabled' ).click(function(e) {
		e.preventDefault();
	});
	
	$( '#bt-limpar' ).click(function(e) {
		e.preventDefault();
		$('#drop').find('figure').remove();
		cont1 = 0; $( '.1' ).text( cont1 );
		cont2 = 0; $( '.2' ).text( cont2 );
		cont3 = 0; $( '.3' ).text( cont3 );
		cont4 = 0; $( '.4' ).text( cont4 );
		cont5 = 0; $( '.5' ).text( cont5 );
		cont6 = 0; $( '.6' ).text( cont6 );
		cont7 = 0; $( '.7' ).text( cont7 );
		cont8 = 0; $( '.8' ).text( cont8 );
		cont9 = 0; $( '.9' ).text( cont9 );
		cont10 = 0; $( '.10' ).text( cont10 );
		cont11 = 0; $( '.11' ).text( cont11 );
		cont12 = 0; $( '.12' ).text( cont12 );
		cont13 = 0; $( '.13' ).text( cont13 );
		cont14 = 0; $( '.14' ).text( cont14 );
		cont15 = 0; $( '.15' ).text( cont15 );
		$( this ).addClass('bt-disabled');
		$( '#bt-descubra' ).addClass('bt-disabled');
	});
	
	$( '#bt-descubra' ).click(function(e){
		e.preventDefault();
		/*
		alert('\
			  Companheiro(a): ' + cont1 + '\
			  Filhos: ' + cont2 + '\
			  Animal: ' + cont3 + '\
			  Amigos: ' + cont4 + '\
			  Piscina: ' + cont5 + '\
			  Churrasqueira: ' + cont6 + '\
			  Dormitorios: ' + cont7 + '\
			  Sala de estar: ' + cont8 + '\
			  Cozinha: ' + cont9 + '\
			  Carro: ' + cont10 + '\
			  Cinema: ' + cont11 + '\
			  Academia: ' + cont12 + '\
			  Quadra: ' + cont13 + '\
			  Escritório: ' + cont14 + '\
			  Biblioteca: ' + cont15 + '\
		');
		*/
		
		if( ! $( this ).hasClass( 'bt-disabled' ) ) {
		
			$( '#load' ).show();
			$( '#load div' ).css({ top : '55%' }).animate({ opacity : 1, top : '50%' }, 500)
				.find(':last').animate({ opacity : 1, 'margin-top' : 0 }, 600);
				
			$('body').addClass('page-resultado');
			
			$.ajax({
				url: 'resultado.html',
				dataType : 'html',
				type: 'GET',
				success: function(data) {
					$('#main').empty().append(data);
					$('#drop').append('\
					<div>\
					<a rel="' + cont1 + cont2 + '">Amor</a>\
					<a rel="' + cont3 + '">Carinho</a>\
					<a rel="' + cont4 + cont6 + '">Amizade</a>\
					<a rel="' + cont5 + cont11 + '">Diversão</a>\
					<a rel="' + cont7 + cont15 + '">Tranquilidade</a>\
					<a rel="' + cont8 + cont10 + '">Conforto</a>\
					<a rel="' + cont9 + cont14 + '">Independência</a>\
					<a rel="' + cont12 + cont13 + '">Saúde</a>\
					</div>\
					');
					
					$( '#drop.tag a' ).tagcloud();
					
					$('#load div')
						.animate({ opacity : 0, top : '40%' }, { duration: 300,
							complete: function() {
								$(this).parent().fadeOut();
							}
						});
				}
			}); // Ajax
		
		} // if
		
	});
	
	
	/**
	 * Qualquer link com href="#" não vai pra lugar algum
	 * 
	 */
	$('a[href=#]').click(function(e){
		e.preventDefault();
	});
	
	
	$(window).load(function(){
		$( '#main' ).show();
		
		$('#load div')
			.animate({ opacity : 0, top : '40%' }, { duration: 300,
				complete: function() {
					$(this).parent().fadeOut();
				}
			});
	});
	
});