
require(["libs/jquery-2.1.0.min.js", "libs/modernizr-2.5.3.min.js"], function() {

    require(["libs/jMobmark.js"], function() {

        $(document).ready(function() {

            jMobmark.googleAnalyticsGenerico('impressao');
            jMobmark.ativaOnRotation('index');
            
            $("body").width(jMobmark.maxWidth);
            $("body").height(jMobmark.maxHeight);
            
            $('body').append('<iframe width="' + jMobmark.maxWidth + '" height="' + jMobmark.maxHeight + '" src="https://www.youtube.com/embed/kQ7kWpTrtJw" frameborder="0" allowfullscreen></iframe>');
        });
    });
});